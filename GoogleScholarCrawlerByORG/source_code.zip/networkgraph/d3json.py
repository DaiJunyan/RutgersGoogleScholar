import pymysql

connect = pymysql.connect(
			host = 'localhost',
			db = 'GoogleScholars',
			user = 'root',
			passwd = '')
cur = connect.cursor()
cur.execute('''SELECT DISTINCT Aid, name 
				FROM authors_to_interests 
				INNER JOIN authors 
				on authors_to_interests.Aid = authors.id
				WHERE Iid != 18''')

print("Starting...")

fhand = open('nodes_links.js','w', encoding='utf-8')

fhand.write('nodes_linksJson={"nodes":[\n')
count = 0
imap = dict()
for row in cur:
	if count > 0 : fhand.write(',\n')
	fhand.write('{'+'"name":"'+str(row[1])+'","id":'+str(row[0])+'}')
	imap[row[0]] = count
	count = count + 1
	if count > 1000: break
fhand.write('],\n')


cur.execute('''SELECT a.Aid, b.Aid
				FROM authors_to_interests a JOIN authors_to_interests b
				ON a.Iid = b.Iid WHERE a.Aid != b.Aid AND a.Iid!=18''')
fhand.write('"links":[\n')

count = 0
links = list()
for row in cur:
	if row[0] not in imap or row[1] not in imap : continue
	id0 = imap[row[0]]
	id1 = imap[row[1]]
	if (id1, id0) in links: continue
	if count > 0: fhand.write(',\n')
	fhand.write('{"source":' + str(imap[row[0]]) + ',"target":' + str(imap[row[1]]) + ',"value":3}')
	links.append(tuple((id0,id1)))
	count = count + 1

fhand.write(']};')
fhand.close()
cur.close()

print("Done.")