For now, the source codes contains three parts:
1. GoogleScholarCrawlerByORG:
	This folder contains the python scraping program we used to collect data from Google Scholar
2. networkgraph:
	This folder contains the code to generate the network graph we mentioned in our report using D3.js library.
3. interestGraph.py:
	This file is an independent python code to genereate the top 30 interests graph we mentioned in our report.
Note: Since part 2 and part 3 require data to load and the assginment asks us not to attach our data sets, you may not be able to run the program successfully and get the graph we show in the report.